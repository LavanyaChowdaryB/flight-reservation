package org.capgemini.flight.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Document(collection="Flight")
public class Flight {
     @Id
private int id;;
private int flightCharge;
private int flightNumber;
public Flight() {
	
}



public Flight(int i,int i1, int i3) {
	}




public int getId() {
	return id;
}




public void setId(int id) {
	this.id = id;
}




public int getFlightCharge() {
	return flightCharge;
}




public void setFlightCharge(int flightCharge) {
	this.flightCharge = flightCharge;
}




public int getFlightNumber() {
	return flightNumber;
}




public void setFlightNumber(int flightNumber) {
	this.flightNumber = flightNumber;
}




public int updatedId() {
	return id; 
     }

}
